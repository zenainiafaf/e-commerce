from flask import Flask, render_template, request, redirect, url_for, jsonify, session, send_file
from flask_sqlalchemy import SQLAlchemy
import stripe
from generate_invoice import generate_invoice
from flask_mail import Mail, Message
import os
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from pusher_config_example import pusher_client

app = Flask(__name__)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ecommerce.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'secret'

# Stripe
stripe.api_key = "sk_test_51QvzwnKSOPBHXeDw42sm4oSPse5qFD7nGcL4xf8VfshNGzj5R4Sluqc52H4JQSOBBGVhVlmk9Uyd5uAVLKTjCS6e00jr9FVFFv"
STRIPE_PUBLIC_KEY = "pk_test_51QvzwnKSOPBHXeDwplHTdeSwlDRgi1B3ZwpZAY638AuTJaWDL7R9WYQRmat6KNLWaCHvrECsVSVlwOZWXkzhpDku0093aRotO1"

# Mail
app.config['MAIL_SERVER'] = 'smtp.office365.com'

app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'lizamezioug03@outlook.com'
app.config['MAIL_PASSWORD'] = 'Liza792003'
mail = Mail(app)

# DB
db = SQLAlchemy(app)

# Models
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    image = db.Column(db.String(255), nullable=False)
    stock = db.Column(db.Integer, nullable=False)
    is_auction = db.Column(db.Boolean, default=False)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(200))

class Auction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    product = db.relationship('Product')

class Bid(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(120))
    auction_id = db.Column(db.Integer, db.ForeignKey('auction.id'))
    amount = db.Column(db.Float)
    bid_time = db.Column(db.DateTime, default=datetime.utcnow)
    auction = db.relationship('Auction')

# Init DB + insert data
with app.app_context():
    db.create_all()
    if not Product.query.first():
        sample_products = [
            Product(name="Laptop", price=799.99, image="laptop.jpg", stock=10),
            Product(name="Smartphone", price=499.99, image="Teljpg.jpg", stock=15),
            Product(name="Casque Bluetooth", price=59.99, image="Casque.jpg", stock=20),
            Product(name="Souris Gamer", price=29.99, image="souris.jpg", stock=30),
            Product(name="Clavier Mécanique", price=89.99, image="clavier.jpg", stock=25),
            Product(name="Bag Dior", price=3999.99, image="Dior.jpg", stock=1, is_auction=True),
            Product(name="Bag Chanel", price=2999.99, image="Chanel.jpg", stock=1, is_auction=True),
            Product(name="Bag Gucci", price=2000.00, image="Gucci.jpg", stock=1, is_auction=True),
            Product(name="Bag Louis Vuitton", price=1499.99, image="Louis_Vuitton.jpg", stock=1, is_auction=True)
        ]
        db.session.add_all(sample_products)
        db.session.commit()

    if not Auction.query.first():
        now = datetime.utcnow()
        auction_products = Product.query.filter_by(is_auction=True).all()
        for product in auction_products:
            auction = Auction(
                product_id=product.id,
                start_time=now,
                end_time=now + timedelta(hours=2),
                is_active=True
            )
            db.session.add(auction)
        db.session.commit()


# Page d'accueil
@app.route('/')
def index():
    products = Product.query.all()
    cart_items = session.get('cart', {})
    cart_count = sum(cart_items.values())
    return render_template('index.html', products=products, cart_count=cart_count, stripe_public_key=STRIPE_PUBLIC_KEY)

        #authentification
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            return "Champs manquants", 400

        user = User.query.filter_by(email=email).first()
        if user:
            # Connexion
            if check_password_hash(user.password, password):
                session['customer_email'] = email  # ✅ AJOUT ICI
                return redirect(url_for('index'))
            else:
                return "Mot de passe incorrect", 403
        else:
            # Création de compte
            hashed_password = generate_password_hash(password)
            db.session.add(User(email=email, password=hashed_password))
            db.session.commit()
            session['customer_email'] = email  # ✅ AJOUT ICI AUSSI
            return redirect(url_for('index'))

    return render_template('login.html')

# Page du panier
@app.route('/cart')
def cart():
    cart_items = session.get('cart', {})
    cart_data = []
    total_price = 0

    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            total_price += product.price * quantity
            cart_data.append({'product': product, 'quantity': quantity})

    return render_template('cart.html', cart_items=cart_data, total_price=total_price)

# Ajouter au panier
@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    product = Product.query.get(product_id)
    if not product or product.stock <= 0:
        return jsonify({'error': 'Stock insuffisant'}), 400

    cart = session.get('cart', {})

    # Vérifier que l'ajout ne dépasse pas le stock disponible
    if cart.get(str(product_id), 0) >= product.stock:
        return jsonify({'error': 'Stock insuffisant'}), 400

    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session['cart'] = cart
    session.modified = True

    return jsonify({'cart_count': sum(cart.values())})


# Diminuer la quantité dans le panier
@app.route('/decrease_cart/<int:product_id>', methods=['POST'])
def decrease_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        session['cart'][str(product_id)] -= 1

        if session['cart'][str(product_id)] <= 0:
            del session['cart'][str(product_id)]

        session.modified = True

    return jsonify({'cart_count': sum(session['cart'].values()) if session['cart'] else 0})

# Supprimer un produit du panier
@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        del session['cart'][str(product_id)]
        session.modified = True

    return jsonify({'cart_count': sum(session['cart'].values()) if session['cart'] else 0})

# Vider le panier
@app.route('/clear_cart')
def clear_cart():
    session.pop('cart', None)
    return redirect(url_for('cart'))

# Créer une session de paiement Stripe
@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    if 'customer_email' not in session:
        print("❌ Utilisateur non connecté — redirection vers login")
        return redirect(url_for('login'))  # Rediriger vers la page de connexion

    cart_items = session.get('cart', {})
    line_items = []

    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            line_items.append({
                'price_data': {
                    'currency': 'eur',
                    'product_data': {'name': product.name},
                    'unit_amount': int(product.price * 100),
                },
                'quantity': quantity
            })

    if not line_items:
        return redirect(url_for('cart'))

    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            success_url=url_for('success', _external=True),
            cancel_url=url_for('cart', _external=True),
        )
        return redirect(checkout_session.url, code=303)
    except Exception as e:
        return str(e), 400

# Page de succès après paiement
@app.route('/success')
def success():
    cart_items = session.get('cart', {})

    if not cart_items:
        return redirect(url_for('index'))  # Rediriger si le panier est vide

    # Récupérer les informations du client depuis Stripe
    payment_intent = session.get('payment_intent', {})
    customer_name = session.get('customer_name', 'Client inconnu')
    customer_email = session.get('customer_email', '')
    order_id = f"CMD{int(datetime.now().timestamp())}"

    # Préparer les données pour la facture
    items = []
    total_price = 0
    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            items.append({
                'name': product.name,
                'quantity': quantity,
                'price': product.price
            })
            total_price += product.price * quantity
            product.stock -= quantity  # Mise à jour du stock

    db.session.commit()  # Sauvegarde des modifications

    # Générer la facture
    invoice_path = generate_invoice(order_id, customer_name, customer_email, items, total_price)

    # Envoyer la facture par e-mail
    if customer_email:
        try:
            msg = Message("Votre Facture", sender=app.config['MAIL_USERNAME'], recipients=[customer_email])
            msg.body = "Veuillez trouver votre facture ci-jointe."
            with app.open_resource(invoice_path) as fp:
                msg.attach(os.path.basename(invoice_path), "application/pdf", fp.read())
            mail.send(msg)
        except Exception as e:
            print(f"Erreur lors de l'envoi de l'email: {e}")

    # Vider le panier après la facture
    session.pop('cart', None)

    return render_template('success.html', invoice_path=invoice_path)





@app.route('/generate_invoice', methods=['POST'])
def generate_invoice_route():
    data = request.json
    if not data or 'order_id' not in data or 'customer_name' not in data or 'items' not in data or 'total_price' not in data:
        return jsonify({"error": "Données invalides"}), 400

    order_id = data['order_id']
    customer_name = data['customer_name']
    items = data['items']
    total_price = data['total_price']

    invoice_path = generate_invoice(order_id, customer_name, items, total_price)

    if invoice_path and os.path.exists(invoice_path):
        return send_file(invoice_path, as_attachment=True)
    return jsonify({"error": "Échec de la génération de la facture"}), 500

# ---------------- ENCHÈRES EN DIRECT ----------------
@app.route('/live_auctions')
def live_auctions():
    auctions = Auction.query.filter_by(is_active=True).all()
    return render_template('live_auctions.html', auctions=auctions)

# Route pour afficher les enchères
@app.route('/auction/<int:auction_id>')
def auction_detail(auction_id):
    auction = Auction.query.get_or_404(auction_id)
    # Vérifier si l'enchère est active
    if auction.is_active:
        return render_template('auction_detail.html', auction=auction)
    else:
        return "Cette enchère a déjà été terminée.", 404


@app.route('/place_bid/<int:auction_id>', methods=['POST'])
def place_bid(auction_id):
    if 'customer_email' not in session:
        return redirect(url_for('login'))
    data = request.json
    amount = data.get('amount')
    email = session.get('customer_email')
    bid = Bid(user_email=email, auction_id=auction_id, amount=amount)
    db.session.add(bid)
    db.session.commit()
    pusher_client.trigger(f"auction-{auction_id}", "new-bid", {'email': email, 'amount': amount})
    return jsonify({'success': True})

# ---------------- HISTORIQUE ----------------
@app.route('/history')
def history():
    if 'customer_email' not in session:
        return redirect(url_for('login'))
    email = session['customer_email']
    bids = Bid.query.filter_by(user_email=email).all()
    return render_template('history.html', bids=bids)

# ---------------- ADMIN ----------------
@app.route('/admin')
def admin():
    if session.get('customer_email') != 'admin@admin.com':
        return redirect(url_for('login'))
    ended_auctions = Auction.query.filter(Auction.end_time < datetime.utcnow()).all()
    result = []
    for auction in ended_auctions:
        highest_bid = Bid.query.filter_by(auction_id=auction.id).order_by(Bid.amount.desc()).first()
        result.append((auction, highest_bid))
    return render_template('admin.html', ended_auctions=result)





if __name__ == '__main__':
    app.run(debug=True)

