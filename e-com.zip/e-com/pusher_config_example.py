import pusher

pusher_client = pusher.Pusher(
  app_id='1977449',
  key='2190128f364a7652a6b4',
  secret='e51bc3614e86e5b415ec',
  cluster='mt1',
  ssl=True
)


